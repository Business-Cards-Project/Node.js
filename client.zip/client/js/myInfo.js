$(() => {
  init();
})

const init = async() => {
  // כל עמוד שלמשתמש חייב להיות מחובר
  // נקרא לפונקציה הזאת
  let user = await checkToken("http://localhost:3000/users/userInfo");
  printUserData(user);
}

const printUserData = (user) => {
  $("#id_name").html(user.name); 
  $("#id_email").html(user.email); 
  $("#id_date").html(user.createdAt); 
}