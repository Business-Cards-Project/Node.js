let userData

$(() => {
  init();
})

const init = async() => {
  // בודק שיש טוקן
  userData = await checkToken("http://localhost:3000/users/userInfo");
  let url = "http://localhost:3000/users/userCards"
  // אוסף את הקלפים שעשינו להם פייבוריט
  // TODO: להפוך לראוט חדש שיודע לאסוף את הכרטיסים שיצרנו
  let cardsData = await doApiMethod(url,"GET");
  createCards(cardsData);
  console.log(cardsData);
}


const createCards = (_ar) => {
  _ar.map(item => {
    let card = new Card("#id_row",item);
    card.render();
  })
} 


