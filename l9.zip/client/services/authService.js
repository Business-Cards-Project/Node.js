// בודק אם טוקן קיים ותקין אם לא נשגר לעמוד לוג אין בחזרה
const checkToken = async(_url) => {
  // קודם בודק בכלל שהטוקן קיים
  if(!localStorage["tok"]){
   return window.location.href = "login.html"
  }
  // let url = "http://localhost:3000/users/userInfo";
  try{
    let data = await doApiMethod(_url,"GET");
    // טוקן לא תקין
    if(!data._id){
      // חוץ מלהחזיר לעמוד הבית גם נמחוק את הטוקן
      // כדי למנוע באגים בהמשך
      localStorage.removeItem("tok");
      window.location.href = "login.html"
    }
    console.log("you logged");
    return data;
  } 
  catch(err){
    console.log(err);
    return err;
  }
  // console.log(data);

}